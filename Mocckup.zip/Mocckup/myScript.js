function ValidateForm() {
        var regex;
        var isValid = true;
        var isName = true;
        var isPassword = true;
        var isEmail = true;
        var isEmp = true;
        var isError = false;

        var errmsg = jQuery("#errmessage");
        
        var name1 = $("#name").val();
        var namemsg = jQuery("#namemessage");

         if(name1=="")
        {
            isError =true;
        }
        else{
             regex = /\b[a-zA-Z]{3,8}\b/;
             if(regex.test(name1)) { 
             }
               else {
                isName = false;
                isValid = false;
               }
        }

        var pwd1 = $("#pwd").val();
        var pwdmsg = jQuery("#pwdmessage");
        var conp1 = $("#conp").val();
        regex = /\b[a-zA-Z0-9]{8,}\b/;

        if (regex.test(pwd1) && pwd1===conp1) { 
        }
        else {
            isPassword = false;
            isValid = false;
        }

        var email1 = $("#email").val();
        var emailmsg = jQuery("#emailmessage");
        regex = /\b[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}\b/;
        
        if (regex.test(email1)) { 
        }
        else {
            isValid = false;
            isEmail = false;
        }

        var emp1 = $("#emp").val();
        var empmsg = jQuery("#empmessage");
        regex = /\b[a-zA-Z]+\b/;
        
        if (regex.test(emp1)) {

        }
        else {
            isValid = false;
            isEmp = false;
        }   

        if(isError === true){
            errmsg.html("Empty field");
        }
        
        else{
            if (isValid === false){
                if(isName === false){
                namemsg.html("Name Not Valid");
                }
                if(isEmail === false){
                emailmsg.html("Email Not Valid");
                }
                if(isPassword === false){
                pwdmsg.html("Password Not Valid");
                }
                if(isEmp === false){
                empmsg.html("Employee Id Not Valid");
                }
            }
            else{
                 alert("Username"+name1+"\n"+"Email"+email1);
            }

        }

}

function ResetMessage() {
     document.getElementById("myForm").reset();
     document.getElementById("myForm1").reset();
}